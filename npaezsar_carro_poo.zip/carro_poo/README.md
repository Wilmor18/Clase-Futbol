# Caso Carro

## Diagrama de clases
![Diagrama de Clases](diagrama.png "Diagrama de Clases")